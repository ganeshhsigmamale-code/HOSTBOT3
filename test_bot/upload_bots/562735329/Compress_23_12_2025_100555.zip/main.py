#!/usr/bin/env python3
"""
Main entry point for Shopify Bot
This file ensures shopifywala.py runs on Railway/hosting platforms
"""

import subprocess
import sys
import os

# Required packages - embedded in main.py
REQUIRED_PACKAGES = [
    'telethon>=1.24.0',
    'requests>=2.28.0',
    'httpx>=0.23.0',
    'faker>=18.0.0'
]

def install_package(package):
    """Install a single package"""
    print(f"🔄 Installing {package}...")
    try:
        # Try with --break-system-packages first
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package, "--break-system-packages", "-q"],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            # Retry without --break-system-packages
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package, "-q"],
                capture_output=True,
                text=True
            )
        
        if result.returncode == 0:
            print(f"✅ Installed {package}")
            return True
        else:
            print(f"⚠️ Failed to install {package}")
            return False
            
    except Exception as e:
        print(f"❌ Error installing {package}: {e}")
        return False

def check_and_install_requirements():
    """Check and install required packages"""
    print("📦 Checking required packages...")
    
    missing_packages = []
    
    # Check each package
    for package in REQUIRED_PACKAGES:
        package_name = package.split('>=')[0].split('==')[0]
        try:
            __import__(package_name)
            print(f"✓ {package_name} already installed")
        except ImportError:
            missing_packages.append(package)
    
    # Install missing packages
    if missing_packages:
        print(f"\n🔧 Installing {len(missing_packages)} missing package(s)...")
        for package in missing_packages:
            install_package(package)
        print("✅ All packages ready!")
    else:
        print("✅ All packages already installed!")

def cleanup_old_sessions():
    """Delete only bot session files (not user data)"""
    session_files = [
        'cc_bot.session',
        'cc_bot.session-journal',
        'bot.session',
        'bot.session-journal'
    ]
    
    print("🗑️ Cleaning up old session files...")
    deleted = 0
    for file in session_files:
        try:
            if os.path.isfile(file):
                os.remove(file)
                print(f"✅ Deleted: {file}")
                deleted += 1
        except Exception as e:
            pass
    
    if deleted > 0:
        print(f"✅ Cleaned {deleted} session file(s)")
    else:
        print("✓ No old session files found")

if __name__ == "__main__":
    print("🚀 Starting Shopify Bot...")
    print(f"📁 Current directory: {os.getcwd()}")
    print(f"📄 Files in directory: {os.listdir('.')}")
    print(f"🐍 Python version: {sys.version}")
    print("-" * 50)
    
    # Cleanup old session files only
    cleanup_old_sessions()
    
    print("-" * 50)
    
    # Check and install required packages
    check_and_install_requirements()
    
    print("-" * 50)
    print(f"▶️ Running: {sys.executable} shopifywala.py")
    print("-" * 50)
    
    # Run shopifywala.py and stream output
    process = subprocess.Popen(
        [sys.executable, "shopifywala.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        bufsize=1
    )
    
    # Print output in real-time
    for line in process.stdout:
        print(line, end='')
    
    process.wait()
    print(f"\n⚠️ Bot stopped with exit code: {process.returncode}")
